# Class 4
List of topics discussed in class 4 are as follows
* If-else statements
* Lists
* List operations
	* Insert
	* Remove
	* Slicing
	* pop
	* append
* For loop