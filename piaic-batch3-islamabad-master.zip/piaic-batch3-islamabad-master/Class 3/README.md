# Class 3
Content discussed in class 3 is as follows.

* Basic Operation with String Types
	* strip, rstrip, lstrip
	* Split, Join Method
	* Concatenation
		* Using %
		* Using +
		* Using f
		* Using .format wihtout naming and with naming
* Arithematic Operations
	* Basic Operators
	* Comparison Operators
	* Assignment Operators
	* Logical Operators
	* Bitwise Operators
	* Membership Operators
	* Identity Operators
* If statements
* Comparison Operators: `==`, `!=`, `>=`, `<=`, `>`, `<`
* Else, Elif Statements
* Testing Sets of Conditions
* Nested if/else